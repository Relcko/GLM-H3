import { Head, Link, router, useForm } from '@inertiajs/react';
import { useState } from 'react';
import AdminLayout from '@/Layouts/AdminLayout';
import {
    ArrowLeftIcon,
    UserIcon,
    ShieldCheckIcon,
    WalletIcon,
    CurrencyDollarIcon,
    BuildingOfficeIcon,
    CheckBadgeIcon,
    XCircleIcon,
    ClockIcon,
} from '@heroicons/react/24/outline';

interface KycVerification {
    id: number;
    status: string;
    document_type: string;
    submitted_at: string | null;
    verified_at: string | null;
}

interface Property {
    id: number;
    title: string;
    slug: string;
    location: string;
}

interface TokenHolding {
    id: number;
    token_amount: number;
    total_invested: number;
    property: Property;
}

interface Investment {
    id: number;
    tokens_purchased: number;
    amount_paid: number;
    status: string;
    created_at: string;
    property: Property;
}

interface User {
    id: number;
    name: string;
    email: string;
    wallet_address: string | null;
    is_admin: boolean;
    created_at: string;
    kyc_verification: KycVerification | null;
    token_holdings: TokenHolding[];
    investments: Investment[];
}

interface Stats {
    total_invested: number;
    properties_owned: number;
    total_tokens: number;
}

interface AdminUsersShowProps {
    user: User;
    stats: Stats;
}

function formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

function formatAddress(address: string): string {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

function formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
    }).format(amount);
}

export default function AdminUsersShow({ user, stats }: AdminUsersShowProps) {
    const { data, setData, put, processing, errors } = useForm({
        name: user.name,
        email: user.email,
        is_admin: user.is_admin,
    });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        put(`/admin/users/${user.id}`);
    };

    const kycStatusConfig: Record<string, { color: string; icon: any }> = {
        pending: { color: 'bg-gray-500/20 text-gray-400 border-gray-500/30', icon: ClockIcon },
        submitted: { color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30', icon: ClockIcon },
        approved: { color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30', icon: CheckBadgeIcon },
        rejected: { color: 'bg-red-500/20 text-red-400 border-red-500/30', icon: XCircleIcon },
    };

    const investmentStatusConfig: Record<string, string> = {
        pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
        confirmed: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
        rejected: 'bg-red-500/20 text-red-400 border-red-500/30',
    };

    return (
        <AdminLayout title="User Details">
            <Head title={`${user.name} - Admin`} />

            {/* Back Button */}
            <div className="mb-6">
                <Link
                    href="/admin/users"
                    className="inline-flex items-center text-gray-400 hover:text-white transition-colors"
                >
                    <ArrowLeftIcon className="h-5 w-5 mr-2" />
                    Back to Users
                </Link>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* User Info Card */}
                <div className="lg:col-span-1">
                    <div className="glass-card rounded-2xl p-6">
                        <div className="text-center mb-6">
                            <div className="h-20 w-20 rounded-2xl gradient-bg flex items-center justify-center mx-auto mb-4">
                                <span className="text-white text-3xl font-bold">
                                    {user.name.charAt(0).toUpperCase()}
                                </span>
                            </div>
                            <h2 className="text-xl font-semibold text-white">{user.name}</h2>
                            <p className="text-gray-400">{user.email}</p>
                            {user.is_admin && (
                                <span className="inline-flex items-center mt-2 px-3 py-1 text-xs font-medium rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/30">
                                    <ShieldCheckIcon className="h-3.5 w-3.5 mr-1.5" />
                                    Administrator
                                </span>
                            )}
                        </div>

                        {/* Wallet */}
                        <div className="border-t border-white/10 pt-4 mb-4">
                            <p className="text-sm text-gray-400 mb-2">Wallet Address</p>
                            {user.wallet_address ? (
                                <div className="flex items-center text-emerald-400 bg-emerald-500/10 rounded-xl p-3">
                                    <WalletIcon className="h-5 w-5 mr-2" />
                                    <span className="font-mono text-sm">{formatAddress(user.wallet_address)}</span>
                                </div>
                            ) : (
                                <div className="text-gray-500 bg-white/5 rounded-xl p-3 text-center">
                                    No wallet connected
                                </div>
                            )}
                        </div>

                        {/* KYC Status */}
                        <div className="border-t border-white/10 pt-4 mb-4">
                            <p className="text-sm text-gray-400 mb-2">KYC Status</p>
                            {user.kyc_verification ? (
                                <div className={`inline-flex items-center px-3 py-1 text-xs font-medium rounded-full border ${kycStatusConfig[user.kyc_verification.status]?.color}`}>
                                    {user.kyc_verification.status === 'submitted' ? 'Pending Review' : user.kyc_verification.status}
                                </div>
                            ) : (
                                <div className="text-gray-500">Not submitted</div>
                            )}
                        </div>

                        {/* Joined */}
                        <div className="border-t border-white/10 pt-4">
                            <p className="text-sm text-gray-400 mb-1">Joined</p>
                            <p className="text-white">{formatDate(user.created_at)}</p>
                        </div>
                    </div>

                    {/* Stats Card */}
                    <div className="glass-card rounded-2xl p-6 mt-6">
                        <h3 className="font-semibold text-white mb-4">Statistics</h3>
                        <div className="space-y-4">
                            <div className="flex justify-between">
                                <span className="text-gray-400">Total Invested</span>
                                <span className="text-white font-semibold">{formatCurrency(stats.total_invested)}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-400">Properties Owned</span>
                                <span className="text-white font-semibold">{stats.properties_owned}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-400">Total Tokens</span>
                                <span className="text-white font-semibold">{stats.total_tokens}</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Main Content */}
                <div className="lg:col-span-2 space-y-6">
                    {/* Edit Form */}
                    <div className="glass-card rounded-2xl p-6">
                        <h3 className="font-semibold text-white mb-4">Edit User</h3>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <label className="block text-sm text-gray-400 mb-2">Name</label>
                                <input
                                    type="text"
                                    value={data.name}
                                    onChange={(e) => setData('name', e.target.value)}
                                    className="w-full input-dark rounded-xl py-3 px-4"
                                />
                                {errors.name && <p className="text-red-400 text-sm mt-1">{errors.name}</p>}
                            </div>
                            <div>
                                <label className="block text-sm text-gray-400 mb-2">Email</label>
                                <input
                                    type="email"
                                    value={data.email}
                                    onChange={(e) => setData('email', e.target.value)}
                                    className="w-full input-dark rounded-xl py-3 px-4"
                                />
                                {errors.email && <p className="text-red-400 text-sm mt-1">{errors.email}</p>}
                            </div>
                            <div>
                                <label className="flex items-center space-x-3 cursor-pointer">
                                    <input
                                        type="checkbox"
                                        checked={data.is_admin}
                                        onChange={(e) => setData('is_admin', e.target.checked)}
                                        className="form-checkbox h-5 w-5 rounded bg-dark-800 border-white/20 text-blue-600 focus:ring-blue-500"
                                    />
                                    <span className="text-white">Administrator</span>
                                </label>
                            </div>
                            <button
                                type="submit"
                                disabled={processing}
                                className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-colors disabled:opacity-50"
                            >
                                {processing ? 'Saving...' : 'Save Changes'}
                            </button>
                        </form>
                    </div>

                    {/* Token Holdings */}
                    <div className="glass-card rounded-2xl p-6">
                        <h3 className="font-semibold text-white mb-4">Token Holdings</h3>
                        {user.token_holdings.length > 0 ? (
                            <div className="space-y-3">
                                {user.token_holdings.map((holding) => (
                                    <div key={holding.id} className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                                        <div className="flex items-center space-x-3">
                                            <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
                                                <BuildingOfficeIcon className="h-5 w-5 text-blue-400" />
                                            </div>
                                            <div>
                                                <Link
                                                    href={`/properties/${holding.property.slug}`}
                                                    className="text-white font-medium hover:text-blue-400 transition-colors"
                                                >
                                                    {holding.property.title}
                                                </Link>
                                                <p className="text-sm text-gray-400">{holding.property.location}</p>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <p className="text-white font-semibold">{holding.token_amount} tokens</p>
                                            <p className="text-sm text-gray-400">{formatCurrency(holding.total_invested)}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-gray-400 text-center py-8">No token holdings</p>
                        )}
                    </div>

                    {/* Investments */}
                    <div className="glass-card rounded-2xl p-6">
                        <h3 className="font-semibold text-white mb-4">Investment History</h3>
                        {user.investments.length > 0 ? (
                            <div className="space-y-3">
                                {user.investments.map((investment) => (
                                    <div key={investment.id} className="flex items-center justify-between p-4 rounded-xl bg-white/5">
                                        <div className="flex items-center space-x-3">
                                            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                                                <CurrencyDollarIcon className="h-5 w-5 text-emerald-400" />
                                            </div>
                                            <div>
                                                <Link
                                                    href={`/properties/${investment.property.slug}`}
                                                    className="text-white font-medium hover:text-blue-400 transition-colors"
                                                >
                                                    {investment.property.title}
                                                </Link>
                                                <p className="text-sm text-gray-400">{formatDate(investment.created_at)}</p>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <p className="text-white font-semibold">{formatCurrency(investment.amount_paid)}</p>
                                            <span className={`inline-flex items-center px-2 py-0.5 text-xs font-medium rounded-full border ${investmentStatusConfig[investment.status]}`}>
                                                {investment.status}
                                            </span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-gray-400 text-center py-8">No investments</p>
                        )}
                    </div>
                </div>
            </div>
        </AdminLayout>
    );
}
