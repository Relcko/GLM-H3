import{b as o}from"./core-uj0JtSlu.js";import"./index-B6VGUkNs.js";import"./index.es-CJ60zr0-.js";import"./events-DQ172AOg.js";import"./index-nibyPLVP.js";const t=o`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M7 13.99a1 1 0 0 1-1-1V5.4L3.54 7.86a1 1 0 0 1-1.42-1.41L6.3 2.28a1 1 0 0 1 1.41 0l4.17 4.17a1 1 0 1 1-1.41 1.41L8 5.4v7.59a1 1 0 0 1-1 1Z"
    clip-rule="evenodd"
  />
</svg>`;export{t as arrowTopSvg};
