import{b as o}from"./core-uj0JtSlu.js";import"./index-B6VGUkNs.js";import"./index.es-CJ60zr0-.js";import"./events-DQ172AOg.js";import"./index-nibyPLVP.js";const p=o`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M1 7.99a1 1 0 0 1 1-1h7.58L7.12 4.53A1 1 0 1 1 8.54 3.1l4.16 4.17a1 1 0 0 1 0 1.41l-4.16 4.17a1 1 0 1 1-1.42-1.41l2.46-2.46H2a1 1 0 0 1-1-1Z"
    clip-rule="evenodd"
  />
</svg>`;export{p as arrowRightSvg};
